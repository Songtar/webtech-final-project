<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Include database connection
require 'config/db.php';

// Fetch Admin Name
$adminName = $_SESSION['username'] ?? 'Admin';

// Fetch Stats
$totalUsers = $conn->query("SELECT COUNT(*) AS total_users FROM users")->fetch_assoc()['total_users'];
$totalEvents = $conn->query("SELECT COUNT(*) AS total_events FROM events")->fetch_assoc()['total_events'];
$totalSales = $conn->query("SELECT SUM(ticket_price * (max_participants)) AS total_sales FROM events")->fetch_assoc()['total_sales'] ?? 0;

// Fetch Events
$eventsResult = $conn->query("SELECT * FROM events ORDER BY event_date DESC");
$events = [];
while ($row = $eventsResult->fetch_assoc()) {
    $events[] = $row;
}

// Fetch Users
$usersResult = $conn->query("SELECT * FROM users ORDER BY full_name ASC");
$users = [];
while ($row = $usersResult->fetch_assoc()) {
    $users[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background-color: #121212;
            color: #ffffff;
        }

        header {
            background-color: #1f1f1f;
            padding: 15px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            color: #00adb5;
        }

        nav a {
            color: #ffffff;
            text-decoration: none;
            margin-right: 20px;
            font-weight: 600;
        }

        .container {
            padding: 20px;
        }

        .stats {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .card {
            background-color: #1f1f1f;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            text-align: center;
            padding: 20px;
            width: 30%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #333;
            text-align: center;
        }

        button {
            background-color: #00adb5;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #007f7f;
        }

        .chart-container {
            width: 50%;
            margin: 20px auto;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin: 20px auto;
            width: 50%;
            background: #1f1f1f;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        form input, form button {
            padding: 10px;
            border: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<header>
    <h1>Welcome, <?php echo htmlspecialchars($adminName); ?> - Admin Dashboard</h1>
    <nav>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="config/logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <!-- Stats Section -->
    <div class="stats">
        <div class="card">
            <h2><?php echo $totalUsers; ?></h2>
            <p>Total Users</p>
        </div>
        <div class="card">
            <h2><?php echo $totalEvents; ?></h2>
            <p>Total Events</p>
        </div>
        <div class="card">
            <h2>₵<?php echo number_format($totalSales, 2); ?></h2>
            <p>Total Sales</p>
        </div>
    </div>

    <!-- Add Event Form -->
    <h2>Add Event</h2>
    <form action="config/admin_manage.php?action=save_event" method="POST">
        <input type="text" name="event_name" placeholder="Event Name" required>
        <textarea name="event_description" placeholder="Event Description" required></textarea>
        <input type="date" name="event_date" required>
        <input type="time" name="event_time" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="number" name="max_participants" placeholder="Max Participants" required>
        <input type="number" name="ticket_price" placeholder="Ticket Price" required>
        <input type="text" name="image_url" placeholder="Image URL" required>
        <button type="submit">Add Event</button>
    </form>

    <!-- Events Table -->
    <h2>Manage Events</h2>
    <table>
        <tr>
            <th>Event Name</th>
            <th>Date</th>
            <th>Location</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($events as $event): ?>
            <tr>
                <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                <td><?php echo htmlspecialchars($event['event_date']); ?></td>
                <td><?php echo htmlspecialchars($event['location']); ?></td>
                <td>
                    <button onclick="deleteAction('delete_event', <?php echo $event['event_id']; ?>)">Delete</button>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Users Table -->
    <h2>Manage Users</h2>
    <table>
        <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td>
                    <button onclick="deleteAction('delete_user', <?php echo $user['user_id']; ?>)">Delete</button>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Chart Section -->
    <h2>Project Statistics</h2>
    <div class="chart-container">
        <canvas id="projectChart"></canvas>
    </div>
</div>

<script>
    function deleteAction(action, id) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This action cannot be undone.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#00adb5',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `config/admin_manage.php?action=${action}&id=${id}`;
            }
        });
    }

    const ctx = document.getElementById('projectChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Users', 'Events', 'Sales'],
            datasets: [{
                data: [<?php echo $totalUsers; ?>, <?php echo $totalEvents; ?>, <?php echo $totalSales; ?>],
                backgroundColor: ['#00adb5', '#007f7f', '#ff4f5a'],
            }]
        },
        options: {
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
</script>
</body>
</html>
