<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Include database connection
require __DIR__ . '/db.php'; // Correct path for the database connection

// Handle different actions
if (isset($_GET['action'])) {
    $action = $_GET['action'];

    // Delete User
    if ($action == 'delete_user' && isset($_GET['id'])) {
        $userId = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);

        if ($stmt->execute()) {
            header("Location: ../admin_dashboard.php?success=User deleted successfully");
        } else {
            header("Location: ../admin_dashboard.php?error=Failed to delete user");
        }
        exit();
    }

    // Delete Event
    if ($action == 'delete_event' && isset($_GET['id'])) {
        $eventId = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM events WHERE event_id = ?");
        $stmt->bind_param("i", $eventId);

        if ($stmt->execute()) {
            header("Location: ../admin_dashboard.php?success=Event deleted successfully");
        } else {
            header("Location: ../admin_dashboard.php?error=Failed to delete event");
        }
        exit();
    }

    // Add or Edit Event
    if ($action == 'save_event' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $eventId = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
        $eventName = htmlspecialchars($_POST['event_name']);
        $eventDesc = htmlspecialchars($_POST['event_description']);
        $eventDate = $_POST['event_date'];
        $eventTime = $_POST['event_time'];
        $location = htmlspecialchars($_POST['location']);
        $maxParticipants = intval($_POST['max_participants']);
        $ticketPrice = floatval($_POST['ticket_price']);
        $imageUrl = htmlspecialchars($_POST['image_url']);

        if ($eventId > 0) {
            // Edit Event
            $stmt = $conn->prepare("UPDATE events 
                                    SET event_name = ?, event_description = ?, event_date = ?, event_time = ?, location = ?, max_participants = ?, ticket_price = ?, image_url = ?
                                    WHERE event_id = ?");
            $stmt->bind_param("sssssidii", $eventName, $eventDesc, $eventDate, $eventTime, $location, $maxParticipants, $ticketPrice, $imageUrl, $eventId);
        } else {
            // Add Event
            $stmt = $conn->prepare("INSERT INTO events (event_name, event_description, event_date, event_time, location, max_participants, ticket_price, image_url) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssdsi", $eventName, $eventDesc, $eventDate, $eventTime, $location, $maxParticipants, $ticketPrice, $imageUrl);
        }

        if ($stmt->execute()) {
            header("Location: ../admin_dashboard.php?success=Event saved successfully");
        } else {
            header("Location: ../admin_dashboard.php?error=Error saving event");
        }
        exit();
    }
}

// Default: Invalid Action
header("Location: ../admin_dashboard.php?error=Invalid action");
exit();
?>
