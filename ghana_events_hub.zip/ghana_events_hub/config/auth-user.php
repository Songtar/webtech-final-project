<?php
// Start session
session_start();

// Include the database connection
require 'db.php';

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Default response
    $response = ["status" => "error", "message" => "Invalid action specified."];

    // Determine the action: signup or login
    if (isset($_POST['action']) && $_POST['action'] == "signup") {
        // Handle signup
        $full_name = htmlspecialchars(trim($_POST['full_name']));
        $email = htmlspecialchars(trim($_POST['email']));
        $password = htmlspecialchars(trim($_POST['password']));

        // Validate inputs
        if (empty($full_name) || empty($email) || empty($password)) {
            $response["message"] = "All fields are required!";
            echo json_encode($response);
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response["message"] = "Invalid email format!";
            echo json_encode($response);
            exit;
        }

        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists
        $checkEmail = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $result = $checkEmail->get_result();

        if ($result->num_rows > 0) {
            $response["message"] = "Email already exists. Please use another email.";
            echo json_encode($response);
            exit;
        }

        // Insert new user into the database
        $stmt = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $full_name, $email, $hashed_password);

        if ($stmt->execute()) {
            $response["status"] = "success";
            $response["message"] = "Registration successful!";
            echo json_encode($response);
            exit;
        } else {
            $response["message"] = "Error: " . $stmt->error;
            echo json_encode($response);
            exit;
        }

    } elseif (isset($_POST['action']) && $_POST['action'] == "login") {
        // Handle login
        $email = htmlspecialchars(trim($_POST['email']));
        $password = htmlspecialchars(trim($_POST['password']));

        // Validate inputs
        if (empty($email) || empty($password)) {
            $response["message"] = "All fields are required!";
            echo json_encode($response);
            exit;
        }

        // Check if email exists in the database
        $stmt = $conn->prepare("SELECT user_id, full_name, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            // Verify password
            if (password_verify($password, $user['password'])) {
                // Start session and store user details
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $email;

                $response["status"] = "success";
                $response["message"] = "Login successful!";
                echo json_encode($response);
                exit;
            } else {
                $response["message"] = "Incorrect password!";
                echo json_encode($response);
                exit;
            }
        } else {
            $response["message"] = "Email not found. Please sign up first.";
            echo json_encode($response);
            exit;
        }
    } else {
        // Invalid action
        $response["message"] = "Invalid action specified.";
        echo json_encode($response);
        exit;
    }

    // Close the database connection
    $conn->close();
} else {
    // Invalid request method
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
    exit;
}
?>
