<?php
session_start();

// Include the database connection
require __DIR__ . '/db.php';

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.html");
    exit();
}

// Validate event ID from GET request
if (!isset($_GET['event_id']) || empty($_GET['event_id'])) {
    die("Invalid event ID. Please select a valid event.");
}

$event_id = intval($_GET['event_id']); // Sanitize input

// Fetch event details from the database
$stmt = $conn->prepare("SELECT event_name, event_description, ticket_price, max_participants FROM events WHERE event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Event not found. Please try again.");
}

$event = $result->fetch_assoc();

// Handle ticket purchase form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $quantity = intval($_POST['quantity']);

    // Check if quantity is valid
    if ($quantity <= 0) {
        echo "<script>alert('Please select a valid ticket quantity.');</script>";
    } else {
        // Check for ticket availability
        $availableTickets = $event['max_participants'];
        if ($quantity > $availableTickets) {
            echo "<script>alert('Not enough tickets available.');</script>";
        } else {
            // Insert ticket purchase into the database
            $total_price = $quantity * $event['ticket_price'];

            $insertStmt = $conn->prepare("INSERT INTO ticket_sales (user_id, event_id, quantity, total_price, purchase_date) VALUES (?, ?, ?, ?, NOW())");
            $insertStmt->bind_param("iiid", $user_id, $event_id, $quantity, $total_price);

            if ($insertStmt->execute()) {
                // Reduce the available tickets
                $updateStmt = $conn->prepare("UPDATE events SET max_participants = max_participants - ? WHERE event_id = ?");
                $updateStmt->bind_param("ii", $quantity, $event_id);
                $updateStmt->execute();

                echo "<script>
                    alert('Ticket purchase successful!');
                    window.location.href = '../dashboard.php';
                </script>";
            } else {
                echo "<script>alert('Error purchasing ticket. Please try again later.');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Ticket</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background-color: #121212;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #1f1f1f;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            width: 400px;
            text-align: center;
        }
        h2 {
            color: #00adb5;
            margin-bottom: 20px;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        input {
            background-color: #333;
            color: #fff;
        }
        button {
            background-color: #00adb5;
            color: #fff;
            cursor: pointer;
        }
        button:hover {
            background-color: #007b7f;
        }
        p {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Buy Ticket</h2>
        <p><strong>Event:</strong> <?php echo htmlspecialchars($event['event_name']); ?></p>
        <p><strong>Price:</strong> ₵<?php echo number_format($event['ticket_price'], 2); ?></p>
        <p><strong>Description:</strong> <?php echo htmlspecialchars($event['event_description']); ?></p>
        <form method="POST">
            <label for="quantity">Ticket Quantity:</label>
            <input type="number" name="quantity" id="quantity" min="1" max="<?php echo $event['max_participants']; ?>" required>
            <button type="submit">Confirm Purchase</button>
        </form>
    </div>
</body>
</html>
