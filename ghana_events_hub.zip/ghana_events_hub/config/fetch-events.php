<?php
// Include your database connection file
require 'config/db.php';

// Query to fetch event details
$query = "SELECT event_id, event_name, event_description, event_date, event_time, location FROM events";
$result = $conn->query($query);

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'id' => $row['event_id'],
        'title' => $row['event_name'],
        'start' => $row['event_date'] . 'T' . $row['event_time'], // Combine date and time
        'description' => $row['event_description'],
        'location' => $row['location']
    ];
}

// Return the events as JSON
header('Content-Type: application/json');
echo json_encode($events);

// Close the database connection
$conn->close();
?>
