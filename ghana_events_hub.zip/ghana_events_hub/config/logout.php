<?php
session_start();

// Destroy all sessions
session_destroy();

// Redirect based on user type
if (isset($_SESSION['user_id'])) {
    header("Location: ../login.html"); // Redirect admin to admin login page
    exit();
} else {
    header("Location: ../admin_login.php"); // Redirect normal user to user login page
    exit();
}
?>
