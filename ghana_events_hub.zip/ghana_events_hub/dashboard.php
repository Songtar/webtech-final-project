<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Include database connection
require 'config/db.php';

// Fetch stats
$totalEvents = $conn->query("SELECT COUNT(*) AS total_events FROM events")->fetch_assoc()['total_events'];
$totalTickets = $conn->query("SELECT SUM(max_participants) AS total_tickets FROM events")->fetch_assoc()['total_tickets'] ?? 0;
$totalUsers = $conn->query("SELECT COUNT(*) AS total_users FROM users")->fetch_assoc()['total_users'];

// Fetch events
$eventsResult = $conn->query("SELECT * FROM events");
$events = [];
while ($row = $eventsResult->fetch_assoc()) {
    $events[] = $row;
}
$jsonEvents = json_encode(array_map(function ($event) {
    return [
        'title' => $event['event_name'],
        'start' => $event['event_date'],
        'description' => $event['event_description']
    ];
}, $events));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Ghana Events Hub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #121212;
            color: #ffffff;
        }

        header {
            background-color: #1f1f1f;
            padding: 15px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #00adb5;
        }

        nav a {
            color: #ffffff;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
        }

        .container {
            padding: 20px;
            text-align: center;
        }

        .stats, .event-cards {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card, .countdown-card, .event-card {
            background-color: #1f1f1f;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            text-align: center;
            width: 300px;
        }

        .countdown-card {
            position: relative;
            background: linear-gradient(135deg, #ff4f5a, #ff6b6b);
            color: #ffffff;
        }

        /* Snowflake Animation */
        .snowflake {
            position: absolute;
            top: -10px;
            color: #ffffff;
            font-size: 16px;
            animation: snowfall linear infinite;
            pointer-events: none;
        }

        @keyframes snowfall {
            to {
                transform: translateY(300px);
            }
        }

        .event-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }

        .event-card a {
            display: inline-block;
            background-color: #00adb5;
            padding: 10px 15px;
            color: #ffffff;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 10px;
        }

        .calendar {
            max-width: 900px;
            margin: 30px auto;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">Ghana Events Hub</div>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="config/logout.php">Logout</a>
        </nav>
    </header>

    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?> 👋</h1>

        <!-- Stats Section -->
        <div class="stats">
            <div class="stat-card">
                <h2><?php echo $totalEvents; ?></h2>
                <p>Upcoming Events</p>
            </div>
            <div class="stat-card">
                <h2><?php echo $totalTickets; ?>+</h2>
                <p>Tickets Available</p>
            </div>
            <div class="stat-card">
                <h2><?php echo $totalUsers; ?></h2>
                <p>Registered Users</p>
            </div>
        </div>

        <!-- Christmas Countdown -->
        <div class="countdown-card" id="countdown-card">
            <h2>🎄 Christmas Countdown 🎅</h2>
            <div id="countdown"></div>
        </div>

        <!-- Events Grid -->
        <h2>Upcoming Events</h2>
        <div class="event-cards">
            <?php foreach ($events as $event): ?>
                <div class="event-card">
                    <img src="<?php echo htmlspecialchars($event['image_url']); ?>" alt="Event Image">
                    <h3><?php echo htmlspecialchars($event['event_name']); ?></h3>
                    <p><?php echo htmlspecialchars($event['event_description']); ?></p>
                    <a href="config/buy_ticket.php?event_id=<?php echo $event['event_id']; ?>">Buy Ticket</a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Calendar -->
        <div id="calendar" class="calendar"></div>
    </div>

    <!-- Snowflake Effect -->
    <script>
        function createSnowflake() {
            const snowflake = document.createElement('div');
            snowflake.classList.add('snowflake');
            snowflake.innerHTML = '❄';
            snowflake.style.left = Math.random() * 100 + '%';
            snowflake.style.animationDuration = Math.random() * 5 + 3 + 's';
            document.getElementById('countdown-card').appendChild(snowflake);

            setTimeout(() => snowflake.remove(), 8000);
        }

        setInterval(createSnowflake, 200);

        // Christmas Countdown
        const countdownEl = document.getElementById('countdown');
        const christmas = new Date('2024-12-25T00:00:00');

        function updateCountdown() {
            const now = new Date();
            const diff = christmas - now;
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            countdownEl.textContent = `${days} Days to Christmas 🎄`;
        }

        setInterval(updateCountdown, 1000);
        updateCountdown();
    </script>

    <!-- FullCalendar Script -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                events: <?php echo $jsonEvents; ?>,
                eventDidMount: function (info) {
                    info.el.title = info.event.extendedProps.description;
                }
            });
            calendar.render();
        });
    </script>
</body>
</html>
