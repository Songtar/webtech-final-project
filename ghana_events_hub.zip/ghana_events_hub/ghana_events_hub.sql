-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2024 at 05:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ghana_events_hub`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `created_at`) VALUES
(2, 'admin', '$2y$10$gvOsGYiXeE2ji0gzeksx2.a0AtE4msPHok04Ao10zMusZp9yq9ZpC', '2024-12-16 13:57:03');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_description` text NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` varchar(255) NOT NULL,
  `max_participants` int(11) NOT NULL,
  `ticket_price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `participants_left` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `event_description`, `event_date`, `event_time`, `location`, `max_participants`, `ticket_price`, `image_url`, `created_at`, `participants_left`) VALUES
(1, 'Live Music Concert', 'A vibrant music concert featuring popular Ghanaian artists.', '2024-12-25', '19:00:00', 'Accra Sports Stadium', 499, 50.00, 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30', '2024-12-16 10:29:37', 0),
(2, 'Photography Workshop', 'Learn professional photography techniques from industry experts.', '2024-12-15', '10:00:00', 'Takoradi Arts Center', 93, 120.00, 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d', '2024-12-16 10:29:37', 0),
(3, 'Cultural Festival', 'A celebration of Ghanaian culture with food, music, and art.', '2024-12-20', '16:00:00', 'Kumasi Cultural Center', 992, 0.00, 'https://images.unsplash.com/photo-1531058020387-3be344556be6', '2024-12-16 10:29:37', 0),
(4, 'Tech Conference', 'The largest tech conference in Ghana featuring top industry leaders.', '2024-12-30', '09:00:00', 'Accra International Conference Center', 300, 200.00, 'https://images.unsplash.com/photo-1531058020387-3be344556be6', '2024-12-16 10:29:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_sales`
--

CREATE TABLE `ticket_sales` (
  `sale_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_sales`
--

INSERT INTO `ticket_sales` (`sale_id`, `user_id`, `event_id`, `total_price`, `quantity`, `purchase_date`) VALUES
(3, 6, 2, 120, 1, '2024-12-16 13:17:51'),
(4, 6, 3, 0, 1, '2024-12-16 13:22:15'),
(7, 8, 3, 0, 1, '2024-12-16 15:53:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password`, `created_at`) VALUES
(2, 'Kevin', 'knljlamptey@st.ug.edu.gh', '$2y$10$CQYI.VqXCw9Xu91VSH4mC.5Gj6x0fPptVHNO6MmH2FjSB9B5T1p8C', '2024-12-14 12:16:23'),
(6, 'Kevin Lamptey', 'superadmin@gmail.com', '$2y$10$.eGMfvPGR9aYyx3h7YhpeeNaIMcgyC4iLQp3zBARAgag6ONX2JSfq', '2024-12-16 09:56:32'),
(8, 'Kevin Jones Lamptey', 'kevin44@c.com', '$2y$10$BJ0okcumKLa9b5/zpB0l8eKJG0HAlyJ/Yraj/QFoi97nsBVvM77e2', '2024-12-16 15:52:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `ticket_sales`
--
ALTER TABLE `ticket_sales`
  ADD PRIMARY KEY (`sale_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ticket_sales`
--
ALTER TABLE `ticket_sales`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ticket_sales`
--
ALTER TABLE `ticket_sales`
  ADD CONSTRAINT `ticket_sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `ticket_sales_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
