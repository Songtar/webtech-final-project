// Define routes and their corresponding file paths
const routes = {
    "/": "index.html",          // Home
    "/signup": "signup.html",   // Signup page
    "/login": "login.html",     // Login page
    "/dashboard": "dashboard.html" // Dashboard page
};

// Get the main content container
const app = document.getElementById("app");

// Function to display a loading animation while content is being fetched
const showLoading = () => {
    app.innerHTML = `
        <div style="text-align: center; padding: 50px;">
            <div class="spinner"></div>
            <p>Loading...</p>
        </div>
    `;
};

// Function to load content based on the current route
const loadContent = async () => {
    const hash = location.hash || "#/"; // Default to home if no hash
    const route = hash.slice(1);       // Remove "#" from the hash
    const file = routes[route] || "404.html"; // Default to 404 if route not found

    showLoading(); // Show loading spinner while fetching content

    try {
        const response = await fetch(file); // Fetch the HTML file
        if (!response.ok) throw new Error("Network response was not ok");
        const content = await response.text();
        app.innerHTML = content; // Insert content into the app container

        // Scroll to top after content loads
        window.scrollTo(0, 0);

        // Optional: Execute additional scripts for dynamically loaded content
        if (route === "/dashboard") {
            initializeDashboardFeatures();
        }
    } catch (error) {
        app.innerHTML = `
            <div style="text-align: center; padding: 50px;">
                <p>Failed to load page. Please try again later.</p>
                <p>Error: ${error.message}</p>
            </div>
        `;
    }
};

// Optional function to initialize additional features for specific pages
const initializeDashboardFeatures = () => {
    console.log("Dashboard-specific features initialized.");
    // Add additional JS functionality for the dashboard here
};

// Listen for hash changes and load the corresponding content
window.addEventListener("hashchange", loadContent);

// Load initial content on page load
window.addEventListener("DOMContentLoaded", loadContent);

// Spinner styles (You can move this to your CSS file for better management)
const style = document.createElement("style");
style.innerHTML = `
    .spinner {
        width: 50px;
        height: 50px;
        border: 5px solid #f3f3f3;
        border-top: 5px solid #00adb5;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);
