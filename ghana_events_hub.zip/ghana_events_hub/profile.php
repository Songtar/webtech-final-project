<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

require 'config/db.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$user_stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();

// Fetch user tickets from 'ticket_sales' table
$tickets_stmt = $conn->prepare("
    SELECT ts.sale_id, e.event_name, e.event_date, e.location, e.ticket_price 
    FROM ticket_sales ts
    JOIN events e ON ts.event_id = e.event_id
    WHERE ts.user_id = ?
");
$tickets_stmt->bind_param("i", $user_id);
$tickets_stmt->execute();
$tickets = $tickets_stmt->get_result();

// Update profile logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $new_full_name = htmlspecialchars($_POST['full_name']);
        $new_email = htmlspecialchars($_POST['email']);

        $update_stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ? WHERE user_id = ?");
        $update_stmt->bind_param("ssi", $new_full_name, $new_email, $user_id);
        $update_stmt->execute();

        $_SESSION['full_name'] = $new_full_name;
        echo "<script>alert('Profile updated successfully!');</script>";
    }

    if (isset($_POST['delete_ticket'])) {
        $sale_id = intval($_POST['sale_id']);

        $delete_stmt = $conn->prepare("DELETE FROM ticket_sales WHERE sale_id = ?");
        $delete_stmt->bind_param("i", $sale_id);
        $delete_stmt->execute();

        echo "<script>alert('Ticket deleted successfully!'); window.location='profile.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background-color: #121212;
            color: #ffffff;
        }
        header {
            display: flex;
            justify-content: space-between;
            background: #1f1f1f;
            padding: 15px 50px;
        }
        header a {
            color: #00adb5;
            text-decoration: none;
            font-weight: 600;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background: #1f1f1f;
            border-radius: 10px;
        }
        h2 {
            color: #00adb5;
        }
        form input, form button {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
            border: none;
            border-radius: 5px;
        }
        form button {
            background: #00adb5;
            color: #ffffff;
            font-weight: bold;
            cursor: pointer;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 10px;
            border: 1px solid #333;
        }
        .delete-btn {
            background: red;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div>Ghana Events Hub</div>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="config/logout.php">Logout</a>
        </nav>
    </header>

    <!-- Profile Section -->
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?> 👤</h1>

        <!-- Update Profile Form -->
        <h2>Update Profile</h2>
        <form method="POST">
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            <button type="submit" name="update_profile">Update</button>
        </form>

        <!-- Tickets Table -->
        <h2>Your Tickets</h2>
        <table>
            <tr>
                <th>Event Name</th>
                <th>Date</th>
                <th>Location</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <?php while ($ticket = $tickets->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($ticket['event_name']); ?></td>
                <td><?php echo htmlspecialchars($ticket['event_date']); ?></td>
                <td><?php echo htmlspecialchars($ticket['location']); ?></td>
                <td>₵<?php echo number_format($ticket['ticket_price'], 2); ?></td>
                <td>
                    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this ticket?');">
                        <input type="hidden" name="sale_id" value="<?php echo $ticket['sale_id']; ?>">
                        <button type="submit" name="delete_ticket" class="delete-btn">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>

<?php
$user_stmt->close();
$tickets_stmt->close();
$conn->close();
?>
